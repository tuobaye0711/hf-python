from distutils.core import setup

setup(
    name='nester',
    version='1.0.0',
    py_modules=['nester'],
    author='zhleven',
    author_email='tuobaye0711@163.com',
    url='tuobaye.com',
    description='learn to distribute a module'
)