from distutils.core import setup

setup(
    name='athletelist',
    version='1.0.0',
    packages=[''],
    url='tuobaye.com',
    license='MIT',
    author='zhleven',
    author_email='tuobaye0711@163.com',
    description='AthleteList'
)
